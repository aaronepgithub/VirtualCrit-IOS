// Initialize your app
var myApp = new Framework7();

// Export selectors engine
var $$ = Dom7;

// $$('.chip-delete').on('click', function (e) {
//     e.preventDefault();
//     var chip = $$(this).parents('.chip');
//     var chipname = $$(this).siblings().attr("class", "chip-label").html();
//     console.log(chipname);
//     myApp.confirm('Selected - ' + chipname, function () {
//         chip.remove();
//     });
// });

// Pull to refresh content
var ptrContent = $$('.pull-to-refresh-content');
 
// Add 'refresh' listener on it
ptrContent.on('ptr:refresh', function (e) {
    // Emulate 2s loading
    setTimeout(function () {
		myApp.pullToRefreshDone();
		// alert("Done")
    	}, 1000);
});



$$('.chip-label').on('click', function (e) {
    e.preventDefault();
    // var chip = $$(this).parents('.chip');
    // var chipname = $$(this).siblings().attr("class", "chip-label").html();
    var chipname = $$(this).attr("class", "chip-label").html();
    console.log(chipname);
    myApp.confirm('Selected - ' + chipname, function () {
        console.log(chipname);
    });
});

// Add views
var view1 = myApp.addView('#view-1');
var view2 = myApp.addView('#view-2', {
    // Because we use fixed-through navbar we can enable dynamic navbar
    dynamicNavbar: true
});
var view3 = myApp.addView('#view-3');
var view4 = myApp.addView('#view-4');

